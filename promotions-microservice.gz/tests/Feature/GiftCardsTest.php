<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class GiftCardsTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function testExample()
    {
        // Get token for feature testing user
        $urlPath = '/login';
        $username = 'feature@test.ing';
        $password = '123';
        $client = new \GuzzleHttp\Client();
        $httpResponse = $client->request('POST',env('ACCOUNTS_MICROSERVICE').$urlPath,[
            'form_params' => [
                'username'=>$username,
                'password'=>$password
                ]
            ]);
        $response = json_decode($httpResponse->getBody());

        
        
        $userToken = $response->token;

        
        
        // Check if empty cart works
        $response = $this
        ->withHeaders([
            'Authorization' => 'Bearer '.$userToken,
        ])
        ->get('/api/gift-cards');

        $response->assertStatus(200);
    }
}
