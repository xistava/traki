<?php

use Illuminate\Database\Seeder;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(CouponsTableSeeder::class);
        $this->call(AmountCouponsTableSeeder::class);
        $this->call(DiscountCouponsTableSeeder::class);
        $this->call(CouponablesTableSeeder::class);
        $this->call(CouponableExceptionsTableSeeder::class);
        $this->call(GiftCardsTableSeeder::class);
        $this->call(UserDiscountCouponTableSeeder::class);
        $this->call(UserAmountCouponTableSeeder::class);
        $this->call(DiscountCardsTableSeeder::class);
        $this->call(DiscountCardHistoryTableSeeder::class);
    }
}
