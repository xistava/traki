<?php

use Illuminate\Database\Seeder;

class AmountCouponsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        $coupons = \App\Coupon::where('type','AMOUNT_COUPON')->get();
        
        foreach($coupons as $coupon) {
            $amount = rand(50,500);
            \App\AmountCoupon::create(['coupon_id'=>$coupon->id,'code'=>$coupon->code,'amount'=>$amount]);
        }
        
        
        
    }
}
