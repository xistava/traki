<?php

use Illuminate\Database\Seeder;

class CouponablesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $couponIds = \App\Coupon::pluck('id');
        $couponableTypes = collect(['PRODUCT_CATEGORY','PRODUCT']);
        $couponableIds = collect([1,2,3,4,5]);
        
        
        
        foreach($couponIds as $couponId) {
            foreach($couponableTypes as $couponableType) {
                foreach($couponableIds as $couponableId) {
                    \DB::table('couponables')->insert([
                        'coupon_id'=>$couponId,
                        'couponable_type'=>$couponableType,
                        'couponable_id'=>$couponableId
                        ]);
                }
            } 
        }

    }
}
