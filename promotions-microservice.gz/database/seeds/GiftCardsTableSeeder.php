<?php

use Illuminate\Database\Seeder;

class GiftCardsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        $userIds = [1,2,3,4,5,6,7,8,9,10];
        
        
        foreach($userIds as $userId) {
                factory(App\GiftCard::class,2)->create(['user_id'=>$userId]);  
        }

        
        
        
        
    }
}
