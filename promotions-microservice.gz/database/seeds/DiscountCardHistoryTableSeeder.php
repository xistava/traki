<?php

use Illuminate\Database\Seeder;

class DiscountCardHistoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $userIds = [1,2,3,4,5,6,7,8,9,10];
        
        
        foreach($userIds as $userId) {
                factory(App\DiscountCardHistory::class)->create([
                    'user_id'=>$userId,
                    'total_amount_spent'=>0,
                    'discount_rate_earned'=>0.05
                ]);
                
                factory(App\DiscountCardHistory::class)->create([
                    'user_id'=>$userId,
                    'total_amount_spent'=>500,
                    'discount_rate_earned'=>0.1
                ]);
                
                factory(App\DiscountCardHistory::class)->create([
                    'user_id'=>$userId,
                    'total_amount_spent'=>1000,
                    'discount_rate_earned'=>0.15
                ]);
                
        }
    }
}
