<?php

use Illuminate\Database\Seeder;

class DiscountCouponsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $coupons = \App\Coupon::where('type','DISCOUNT_COUPON')->get();
        
        foreach($coupons as $coupon) {
            $rate = round(mt_rand() / mt_getrandmax(),2);
            \App\DiscountCoupon::create(['coupon_id'=>$coupon->id,'code'=>$coupon->code,'rate'=>$rate]);
        }
    }
}
