<?php

use Illuminate\Database\Seeder;

use Carbon\Carbon;

class UserAmountCouponTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $userIds = [1,2,3];
        $amountCoupons = \App\AmountCoupon::get();
        
        foreach($userIds as $userId) {
            $amountCoupon = $amountCoupons->random();
                \App\UserAmountCoupon::create([
                    'user_id' => $userId,
                    'code' => $amountCoupon->code,
                    'amount_coupon_id' => $amountCoupon->id,
                    'amount_spent' => 100,
                    'amount_left' => 50,
                    'validity_date' => Carbon::now()->addMonths(2)
                    ]);
        }
    }
}
