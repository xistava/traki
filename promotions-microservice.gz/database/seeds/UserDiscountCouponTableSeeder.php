<?php

use Illuminate\Database\Seeder;

use Carbon\Carbon;

class UserDiscountCouponTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $userIds = [1,2,3,4,5,6,7,8,9,10];
        $discountCoupons = \App\DiscountCoupon::get();
        
        foreach($userIds as $userId) {
            $discountCoupon = $discountCoupons->random();
                \App\UserDiscountCoupon::create([
                    'user_id' => $userId,
                    'code' => $discountCoupon->code,
                    'discount_coupon_id' => $discountCoupon->id,
                    'amount_spent' => 100,
                    'validity_date' => Carbon::now()->addMonths(2)
                    ]);
        }
    }
}
