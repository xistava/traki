<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\GiftCard;
use Faker\Generator as Faker;

$factory->define(GiftCard::class, function (Faker $faker) {
    return [
        'code' => \Str::random(5),
        'user_id' => 1,
        'amount_left' => 100
    ];
});
