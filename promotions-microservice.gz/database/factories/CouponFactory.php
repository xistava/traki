<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Coupon;
use Faker\Generator as Faker;

$types = collect(['AMOUNT_COUPON','DISCOUNT_COUPON']);
    
$factory->define(Coupon::class, function (Faker $faker) use($types){
    

    return [
        'code' => \Str::random(5),
        'type' => $types->random(),
        'title' => $faker->title(),
        'description' => $faker->text(20),
        'validity_date' => $faker->dateTimeBetween($startDate = '1 years', $endDate = '2 years'),
        'validity_days' => 500
    ];
});
