<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DiscountCardHistory;
use Faker\Generator as Faker;

$factory->define(DiscountCardHistory::class, function (Faker $faker) {
    return [
        'user_id' => 1,
        'total_amount_spent' => 0,
        'discount_rate_earned' => 0.05
    ];
});
