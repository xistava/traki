<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DiscountCard;
use Faker\Generator as Faker;

$factory->define(DiscountCard::class, function (Faker $faker) {
    return [
        'code' => \Str::random(5),
        'user_id' => 1,
        'discount_rate' => 0.15,
        'amount_spent' => 1700
    ];
});
