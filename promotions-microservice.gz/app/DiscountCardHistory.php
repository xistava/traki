<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiscountCardHistory extends Model
{
    protected $table = 'discount_card_history';
    protected $guarded = ['id'];
}
