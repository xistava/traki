<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmountCoupon extends Model
{
    //

    
    public function coupon() {
        return $this->belongsTo('App\Coupon');
    }
    
}


