<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiscountCoupon extends Model
{
    //
    
    public function coupon() {
        return $this->belongsTo('App\Coupon');
    }
    
}
