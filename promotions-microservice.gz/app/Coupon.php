<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class Coupon extends Model
{

    protected $table = 'coupons';
    protected $guarded = ['id'];
    protected $translatable = ['title','description'];
    
    
    
    
    
    
    // // Load amount of discount coupon
    // protected static function boot()
    // {
    //     parent::boot();

    //     static::addGlobalScope('addAmountOrDiscountCouponData', function (Builder $builder) {
    //         $builder->rightJoin('amount_coupons', function($join){
    //             $join->on('coupons.id','=','amount_coupons.coupon_id')->where('coupons.type','AMOUNT_COUPON');
    //         })
    //         ->rightJoin('discount_coupons', function($join){
    //             $join->on('coupons.id','=','discount_coupons.coupon_id')->where('coupons.type','DISCOUNT_COUPON');
    //         });            
    //     });
    // }    
    
    
    
    
    // public function scopeFullCoupon($query)
    // {
    //         return $query->rightJoin('amount_coupons', function($join){
    //             $join->on('coupons.id','=','amount_coupons.coupon_id')->where('coupons.type','AMOUNT_COUPON');
    //         })
    //         ->rightJoin('discount_coupons', function($join){
    //             $join->on('coupons.id','=','discount_coupons.coupon_id')->where('coupons.type','DISCOUNT_COUPON');
    //         });  
    // }    





    public function amountCoupon() {
        return $this->hasOne('App\AmountCoupon');
    }
    
    public function discountCoupon() {
        return $this->hasOne('App\DiscountCoupon');
    }    

}
