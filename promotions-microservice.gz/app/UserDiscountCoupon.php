<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDiscountCoupon extends Model
{
    protected $guarded = ['id'];
    
    
    
    
    public function discountCoupon() {
        return $this->belongsTo('App\DiscountCoupon');
    }
    
    
}
