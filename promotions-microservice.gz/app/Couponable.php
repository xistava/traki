<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Couponable extends Model
{
    //
}
