<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiscountCard extends Model
{


    protected $table = 'discount_cards';
    protected $guarded = ['id'];



}
