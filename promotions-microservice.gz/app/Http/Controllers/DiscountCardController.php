<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App\Http\Resources\DiscountCardResource;

use App\Repositories\RemoteAuth;

class DiscountCardController extends Controller
{
    
    
    
    public function index(Request $request) {
        $discountCard = \App\DiscountCard::where('user_id',RemoteAuth::user()->id)->first();
        // Original code
        // DiscountCardHistoryResource is also changed
        //$discountCardHistory = \App\DiscountCardHistory::where('user_id',RemoteAuth::user()->id)->get();
        $discountCardHistory = \App\DiscountCardHistory::where('user_id',RemoteAuth::user()->id)->orderBy('id','desc')->limit(1)->get();

        return new DiscountCardResource([
            'discount_card'=>$discountCard,
            'discount_card_history'=>$discountCardHistory
            ]);
        
        
        
        
    }
    
    
    
}
