<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Resources\GiftCardsResource;

use App\Repositories\RemoteAuth;


class GiftCardController extends Controller
{
    
    
    
    public function index(Request $request) {
        
        $giftCards = \App\GiftCard::where('user_id',RemoteAuth::user()->id)->get();
        
        return GiftCardsResource::collection($giftCards);
        
    }
    
    
    
    
    
    
    
    
}
