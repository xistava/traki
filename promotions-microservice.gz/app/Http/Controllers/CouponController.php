<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Resources\DiscountCouponsResource;
use App\Http\Resources\AmountCouponsResource;

use App\Repositories\RemoteAuth;

class CouponController extends Controller
{


    public function discountCoupons(Request $request) {
        
        $userDiscountCoupons = \App\UserDiscountCoupon::where('user_id',RemoteAuth::user()->id)->get();
        return DiscountCouponsResource::collection($userDiscountCoupons);
        
    }
    
    
    
    public function amountCoupons(Request $request) {
        
        $userAmountCoupons = \App\UserAmountCoupon::where('user_id',RemoteAuth::user()->id)->get();
        return AmountCouponsResource::collection($userAmountCoupons);
        
    }







}
