<?php

namespace App\Http\Resources\DiscountCard;

use Illuminate\Http\Resources\Json\JsonResource;

class DiscountCardRateResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'discount_rate' => ($this->discount_rate * 100).'%'
            ];
    }
}
