<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class DiscountCouponsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        
        $daysLeft = \Carbon::now()->diffInDays($this->validity_date, false);
        
        return [
            'amount_spent' => $this->amount_spent,
            'validity_date' => $daysLeft.' '.trans_choice('general.day',$daysLeft), // depricated
            'days_left' => $daysLeft.trans_choice(' day',$daysLeft),
            'rate' => ($this->discountCoupon->rate * 100).'%',
            'valid_for' => 'Fragrances',
            'code' => $this->code,            
            'status' => 'active'
            ];
    }
}
