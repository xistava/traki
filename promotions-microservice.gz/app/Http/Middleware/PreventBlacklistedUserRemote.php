<?php

namespace App\Http\Middleware;
use App\Repositories\RemoteAuth;


use Closure;

class PreventBlacklistedUserRemote
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {


        if(RemoteAuth::check()) $checkableUser = RemoteAuth::user();

        
    
        if(isset($checkableUser)) {
            $checkUserBlacklisted = \App\RemoteModels\Accounts\Blacklist::where('user_id',$checkableUser->id)->first();
            
            if($checkUserBlacklisted) {
                 return response()->json(['error'=>'You are in blacklist. Reason: '.$checkUserBlacklisted->reason],403);            
            }              
        }        
          
         
        
        


        
        
        return $next($request);
    }
}
