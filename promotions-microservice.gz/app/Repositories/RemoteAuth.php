<?php

namespace App\Repositories;


class RemoteAuth {
    
    
    private static $user;
    private static $genericUser;
    
    

    
    
  
    /**
     * check bearer token existance
     * 
     * @return boolean
     **/    
    private static function checkBearerTokenExistance() {
        if(request()->bearerToken()==false) return false;
    }    
    
    
    
    
    /**
     * check authentication (user, not generic user)
     * 
     * @return boolean
     **/     
    public static function check() {

        Self::checkBearerTokenExistance();

        if(RemoteAuth::$user) return true;
        else {
            if(Self::retrieveUser()) return true;
            else return false;
        }
        
    }
    
    
    
    
    
    
    /**
     * returns user, if authenticated
     * 
     * @return \App\RemoteModels\Account\GenericUser $user | false
     **/  
    public static function user() {
        
        Self::checkBearerTokenExistance();        
        
        if(RemoteAuth::$user) return RemoteAuth::$user;
        else {
            return Self::retrieveUser();
        }
    }
    
    
    
    
    /**
     * returns generic user
     * 
     * @return \App\RemoteModels\Account\GenericUser $user | false
     **/ 
    public static function genericUser() {
        
        Self::checkBearerTokenExistance();        
        
        if(RemoteAuth::$genericUser) return RemoteAuth::$genericUser;
        else {
            return Self::retrieveGenericUser();
        }
    }












  
    /**
     * retrieve user from accounts microservice
     * 
     * @return \App\RemoteModels\Account\User $user | false
     **/ 
    
    private static function retrieveUser() {
        
        Self::checkBearerTokenExistance();        
        
        $client = new \GuzzleHttp\Client(['headers' => ['Authorization' => 'Bearer '.request()->bearerToken()]]);
        $httpResponse = $client->get(env('ACCOUNTS_MICROSERVICE').'/ms/user',[
            'http_errors' => false
            ]);
        
        if($httpResponse->getStatusCode()!==401) {
            $response = json_decode($httpResponse->getBody());
            RemoteAuth::$user = $response;
            
            return RemoteAuth::$user;
        } else {
            return false;
        }
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * retrieve generic user from accounts microservice
     * 
     * @return \App\RemoteModels\Account\GenericUser $genericUser | false
     **/ 
    private static function retrieveGenericUser() {
        
        
        
        $client = new \GuzzleHttp\Client(['headers' => ['Authorization' => 'Bearer '.request()->bearerToken()]]);
        if(Self::check()) $httpResponse = $client->get(env('ACCOUNTS_MICROSERVICE').'/ms/generic-user/for-user');
        else $httpResponse = $client->get(env('ACCOUNTS_MICROSERVICE').'/ms/generic-user/for-guest',[
            'http_errors' => false
            ]);
        
        if($httpResponse->getStatusCode()!==401) {
            $response = json_decode($httpResponse->getBody());
            RemoteAuth::$genericUser = $response;
            
            return RemoteAuth::$genericUser;
        } else {
            return false;
        }
        
        
        
        
        
    }
    
    
    
    
    
    
    
}