<?php

namespace App\RemoteModels\Accounts;

use Illuminate\Database\Eloquent\Model;

class Blacklist extends Model
{
    //
    protected $table = 'blacklist';
    protected $connection = 'mysql_accounts';
}
