<?php

namespace App\RemoteModels\Products;

use Illuminate\Database\Eloquent\Model;



class ProductCategory extends Model
{

    protected $connection = 'mysql_products';

    

    


    
    
    
}
