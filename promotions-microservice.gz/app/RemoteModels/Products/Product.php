<?php

namespace App\RemoteModels\Products;

use Illuminate\Database\Eloquent\Model;



class Product extends Model
{

    protected $connection = 'mysql_products';

    

    public function categories() {
        return $this->belongsToMany('App\ProductCategory','product_category');
    }

    


    
    
    
}
