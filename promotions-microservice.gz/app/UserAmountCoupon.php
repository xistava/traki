<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAmountCoupon extends Model
{
    protected $guarded = ['id'];
    
    
    public function amountCoupon() {
        return $this->belongsTo('App\AmountCoupon');
    }
    
    
}
