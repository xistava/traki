<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CouponableException extends Model
{
    //
}
