<?php



return [
    
    
    
    'day' => 'day|days'
    
    
    
    ];