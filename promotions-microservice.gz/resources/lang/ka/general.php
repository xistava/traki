<?php



return [
    
    
    
    'day' => 'დღე'
    
    
    
    ];