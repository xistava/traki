<?php



Route::get('gift-cards','GiftCardController@index')->middleware('auth-remote','prevent-blacklisted-user-remote');
Route::get('discount-coupons','CouponController@discountCoupons')->middleware('auth-remote','prevent-blacklisted-user-remote');
Route::get('amount-coupons','CouponController@amountCoupons')->middleware('auth-remote','prevent-blacklisted-user-remote');
Route::get('discount-card','DiscountCardController@index')->middleware('auth-remote','prevent-blacklisted-user-remote');


